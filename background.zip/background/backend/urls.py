from django.urls import path

from . import views

urlpatterns = [
    path('login', views.login),
    path('allInfo', views.allInfo),
    path('updateCustomInfo', views.updateCustomInfo),
    path('checkCustomInfo', views.checkCustomInfo),

]
