from django.db import models

# Create your models here.
class NormalUser(models.Model):
    name = models.CharField(max_length=128, unique=True)
    password = models.CharField(max_length=256)
    authorization = models.CharField(max_length=256)
    def __str__(self):
        return self.name




class CustomInfo(models.Model):
    customName = models.CharField('客户名称',max_length=128, unique=True)
    customID = models.CharField('客户ID',max_length=256)
    startDate = models.CharField('服务器开始维护时间',max_length=256)
    endDate = models.CharField('服务器结束维护时间',max_length=256)
    isOpen = models.BigIntegerField('服务器是否维护')

    def __str__(self):
        return self.customName
    
    def toJSON(self):
        import json
        return json.dumps(dict([(attr, getattr(self, attr)) for attr in [f.name for f in self._meta.fields]]))