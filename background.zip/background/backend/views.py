from django.shortcuts import render
from django.shortcuts import redirect
from django.http import HttpResponse, HttpRequest
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from . import models
import datetime
import time
import uuid
from django.core import serializers
import json

# Create your views here.
@csrf_exempt
def login(request):
    if request.method == "POST":
        userName = request.POST.get('userName')
        password = request.POST.get('password')
        if userName and password:  # 确保用户名不为空
            try:
                userModel = models.NormalUser.objects.get(name=userName)
                print(password,userModel.password)
                if password==userModel.password:
                    token =  uuid.uuid4()
                    models.NormalUser.objects.filter(name=userModel.name).update(authorization=token)
                    return JsonResponse({"returnCode":'0000','token':token,'Message':'登录成功'})
            except:
              return JsonResponse({"returnCode":'0002','Message':'用户或密码错误'})

        return JsonResponse({"returnCode":'0003','Message':'用户或密码为空'})
    pass
    return JsonResponse({"returnCode":'0001','Message':'请求方式错误'})

@csrf_exempt
def allInfo(request):
    if request.method=="POST":
        data = models.CustomInfo.objects.all()
        entry_list = serializers.serialize("json", data)
        j = json.loads(entry_list)
        list = []          ## 空列表
        for item in j:
           list.append(item['fields'])
    #    print(type(j))
        return JsonResponse({"returnCode":'0000','data':list,'Message':'数据获取成功'})
    pass
    return JsonResponse({"returnCode":'0001','Message':'请求方式错误'})

@csrf_exempt
def updateCustomInfo(request):
    if request.method == "POST":
        userName = request.POST.get('userName')
        customID = request.POST.get('customID')
        startDate = request.POST.get('startDate')
        endDate = request.POST.get('endDate')
        isOpen = request.POST.get('isOpen')
        token =  request.POST.get("token")

        if userName:  # 确保用户名不为空
            try:
                userModel = models.NormalUser.objects.get(name=userName)
                print(token == userModel.authorization)
                if token == userModel.authorization and len(token)>10:
                    customModel = models.CustomInfo.objects.get(customID=customID)
                    customModel.startDate = startDate
                    customModel.endDate = endDate
                    customModel.isOpen =  isOpen
                    customModel.save()

                    print({"returnCode":'0000','Message':customModel.customName+'修改成功'})
                    return JsonResponse({"returnCode":'0000','Message':customModel.customName+'修改成功'})
                return JsonResponse({"returnCode":'0004','Message':'用户未登录'})
            except:
              return JsonResponse({"returnCode":'0002','Message':'用户为空'})
        return JsonResponse({"returnCode":'0003','Message':'参数为空'})
    pass
    return JsonResponse({"returnCode":'0001','Message':'请求方式错误'})

@csrf_exempt
def checkCustomInfo(request):
    if request.method == "POST":
        customID = request.POST.get('customID')
        if customID:  
            try:
                customModel = models.CustomInfo.objects.get(customID=customID)
                list = {
                    "customName": customModel.customName,
                    "customID": customModel.customID,
                    "startDate": customModel.startDate,
                    "endDate": customModel.endDate,
                    "isOpen": customModel.isOpen
                }
                return JsonResponse({"returnCode":'0000','returnMap':list,'Message':'数据获取成功'})
            except:
              return JsonResponse({"returnCode":'0003','Message':'参数错误'})
        return JsonResponse({"returnCode":'0002','Message':'参数为空'})
    pass
    return JsonResponse({"returnCode":'0001','Message':'请求方式错误'})

