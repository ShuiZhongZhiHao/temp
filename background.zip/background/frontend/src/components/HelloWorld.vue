<template>
  <div class="hello">
    <div class="top_background"></div>
    <div class="logo_image"></div>
    <h1 v-text="msg"></h1>

    <div class="userName">
          <div class="userName_left">
              <div class="userName_icon"></div>
          </div>
          <div class="userName_right">
              <input class="userName_input" v-model="userName" placeholder="请输入用户名称">
          </div>
    </div>
    <div class="password">
          <div class="password_left">
              <div class="password_icon"></div>
          </div>
          <div class="password_right">
              <input class="password_input" v-model="password" placeholder="请输入登录密码">
          </div>
    </div>
    <button class="login_button" v-on:click="login">登录</button>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: '维护管理后台',
      userName:'',
      password:'',
    }
  },
   // 在 `methods` 对象中定义方法
  methods: {
    login: function (event) {
      // `this` 在方法里指当前 Vue 实例
      if(!this.userName){
         alert('请填写用户名称');
         return;
      }
      if(!this.password){
         alert('请填写登录密码');
         return;
      }
      //发送Post请求
      this.$http.post('http://10.17.162.113:8888/backend/login',{'userName':this.userName,'password':this.password},{emulateJSON:true}).then(function(res){
                  if (res.data.returnCode == '0000'){
                    window.localStorage.setItem("token",res.data.token);
                    window.localStorage.setItem("userName",this.userName);
                    this.$router.push('Content');
                  }else{
                    console.log(res.data.Message)
                  }                  
                },function(res){
                  console.log('2222')
                });
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
  font: 36px;
  color: #50ABFF;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.hello{
  width: 500px;
  height: 500px;
  margin-left: 40%;    
  margin-top: 200px;    
  background-color: white;
  box-shadow: darkgrey 10px 10px 30px 5px ;
}
.top_background{
  height: 10px;
  background-color:#50ABFF;
}
.logo_image{
  width: 100px;
  height: 100px;
  background: url(../assets/icon_logo.png);
  margin: 0 auto;
  margin-top: 40px;
}
.userName{
  width: 80%;
  height: 60px;
  margin:0 auto;
  border: 1px solid rgb(192, 192, 192);
  -moz-border-radius: 5px;      /* Gecko browsers */    
  -webkit-border-radius: 5px;   /* Webkit browsers */    
  border-radius:5px;

}
.userName_left{
  margin-top: 1px;
  margin-left: 1px;
  width: 78px;
  height: 58px;
}
.userName_icon{
  position: absolute;
  margin-left: 25px;
  margin-top: 16px;
  width: 28px;
  height: 28px;
  background: url(../assets/user.png);
}
.userName_right{
   margin-left: 78px;
   margin-top: -58px;
   width: 80%;
   height: 58px;
}
.userName_input{
  background-color: white;
  display: block;
  border: hidden;
  height: 56px;
  width: 100%;
  outline:none;
  padding-left: 0px;
  font-size: 18px;

}
.password{
   width: 80%;
  height: 60px;
  margin:0 auto;
  border: 1px solid rgb(192, 192, 192);
  -moz-border-radius: 5px;      /* Gecko browsers */    
  -webkit-border-radius: 5px;   /* Webkit browsers */    
  border-radius:5px;
  margin-top: 30px;
}
.password_left{
  margin-top: 1px;
  margin-left: 1px;
  width: 78px;
  height: 58px;
}
.password_icon{
  position: absolute;
  margin-left: 25px;
  margin-top: 16px;
  width: 28px;
  height: 28px;
  background: url(../assets/password.png);
}
.password_right{
   margin-left: 78px;
   margin-top: -58px;
   width: 80%;
   height: 58px;
}
.password_input{
  background-color: white;
  display: block;
  border: hidden;
  height: 56px;
  width: 100%;
  outline:none;
  padding-left: 0px;
  font-size: 18px;
}
.login_button{
  width: 80%;
  height: 60px;
  border: hidden;
  background-color:#50ABFF;
  color: white;
  font-size: 25px;
  margin-top: 20px;
  -moz-border-radius: 30px;      /* Gecko browsers */    
  -webkit-border-radius: 30px;   /* Webkit browsers */    
  border-radius:30px;
}
</style>
