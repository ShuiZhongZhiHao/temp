<template>
  <div>
    <div class="top">
        <p  class="title"  v-text="title"></p>
        <p class="exit" @click="exit">退出登录</p>
      </div>
      <div class="table">
            <table >           
                    <tr>
                        <td width="80px">序号</td>
                        <td width="200px">客户名称</td>
                        <td>开始维护时间</td>
                        <td>结束维护时间</td>
                        <td width="200px">状态</td>
                        <td width="120px">操作</td>
                    </tr>
                    <tr v-for="(item, i) in dataArray" :key="item.name" class="content">
                        <td>{{i+1}}</td>  
                        <td>{{item.customName}}</td>
                        <td> 
                          <el-date-picker :class="{'isOpen':!item.isEdit}" class="time" v-model="item.startDate" type="datetime" value-format="timestamp">
                          </el-date-picker>
                          <span :class="{'isOpen':item.isEdit,'time':true}">{{deal(item.startDate)}}</span></td>
                        <td>
                          <el-date-picker :class="{'isOpen':!item.isEdit}" class="time" v-model="item.endDate" type="datetime"  value-format="timestamp">
                          </el-date-picker>
                          <span :class="{'isOpen':item.isEdit,'time':true}">{{deal(item.endDate)}}</span></td>
                        <td>
                          <div v-if="item.isOpen==true" :class="{'isOpen':!item.isEdit}"> 
                            <label>
                            <input type="radio" :name="item.customID" checked="checked" @click="isMaintenance(item)">维护中
                            </label>
                            <label><input type="radio" :name="item.customID" @click="isNormal(item)">正常
                            </label>
                          </div>
                          <div :class="{'isOpen':!item.isEdit}" v-else> 
                            <label>
                            <input type="radio"  :name="item.customID" @click="isMaintenance(item)">维护中
                            </label>
                            <label><input type="radio" :name="item.customID" checked="checked" @click="isNormal(item)">正常
                            </label>
                          </div>
                          <span :class="{isOpen:item.isEdit}" v-if="item.isOpen==true">维护中</span>
                          <span :class="{isOpen:item.isEdit}" v-else>正常</span>
                        </td>
                        <td>
                          <!-- {{upDateName}} -->
                          <span @click="saveContent(item,i,'保存')" v-if="item.isEdit==true">保存</span>
                          <span @click="saveContent(item,i,'修改')" v-else>修改</span>
                        </td>
                    </tr>             
            </table>
       </div>
  </div>
</template>
<script>
 
export default {
  name: 'Content',
  created(){
    this.getAllData()
  },
  data () {
    return {
      title: '维护管理后台',
      upDateName:'修改',
      falg:true,
      item:{},
      dataArray: [
        {
          customName: 'Zhangsan',
          startDate: '1550563475000',
          endDate: '1550563475000',
          isOpen:false,
      }
      ]
    }
  },
  methods: {

    getAllData(){
      let token =  window.localStorage.getItem("token");
      console.log(token)
      if(!token){
        window.localStorage.clear;
        this.$router.push('/');
        this.$message({
        message: "已退出登录",
        type: 'success'
        });
        return;
      }
      this.$http.post('http://10.17.162.113:8888/backend/allInfo',{},{emulateJSON:true}).then(function(res){
              if (res.data.returnCode == '0000'){
                this.dataArray = res.data.data;
                console.log(res)
              }else{
                console.log(res.data.Message)
              }                  
            },function(res){
              console.log('2222')
            });
    },
    updateData(){
      let token =  window.localStorage.getItem("token");
      if(!token){
        window.localStorage.clear;
        this.$router.push('/');
        return;
      }
      let userName =  window.localStorage.getItem("userName");
      console.log(token,userName)
      var data = {
        "token":token,
        "userName":userName,
        "customID":this.item.customID,
        "startDate":this.item.startDate,
        "endDate":this.item.endDate,
        "isOpen":this.item.isOpen,
        }
      this.$http.post('http://10.17.162.113:8888/backend/updateCustomInfo',data,{emulateJSON:true}).then(function(res){
              if (res.data.returnCode == '0000'){
                this.$message({
                  message: res.data.Message,
                  type: 'success'
                });
              }else{
                this.$message.error(res.data.Message);
              }                  
            },function(res){
              console.log('2222')
            });
        
    },
    //服务器是正常或者维护中
    isNormal(item){
      this.item = item;
      this.item.isOpen = 0;
      console.log(item);
    },
    isMaintenance(item){
      this.item = item;
      this.item.isOpen = 1;
      console.log(item);
    },
    //时间戳转换成 
    deal(val){
      var unixtime = parseInt(val)
      var unixtimestamp = new Date(unixtime);
      var year = 1900 + unixtimestamp.getYear();
      var month = "0" + (unixtimestamp.getMonth() + 1);
      var date = "0" + unixtimestamp.getDate();
      var hour = "0" + unixtimestamp.getHours();
      var minute = "0" + unixtimestamp.getMinutes();
      var second = "0" + unixtimestamp.getSeconds();
      return year + "-" + month.substring(month.length-2, month.length)  + "-" + date.substring(date.length-2, date.length)
            + " " + hour.substring(hour.length-2, hour.length) + ":"
            + minute.substring(minute.length-2, minute.length) + ":"
            + second.substring(second.length-2, second.length);
    },
    //保存修改到的数据
    saveContent(item,i,style) {
      item.isEdit = !item.isEdit;
      // `this` 在方法里指当前 Vue 实例
      this.item = item;
      console.log(item);
      if(style === "保存"){
        this.updateData();
      }else{
        this.startDate = Number(this.startDate);
        this.endDate = Number(this.endDate);
      }
      this.$set(this.dataArray,i,item)

    },
    exit:function(){
      console.log("退出登录")
      window.localStorage.clear();
      this.$router.push('/');

      // this.$router.go(-1);
      this.$message({
        message: "已成功退出登录",
        type: 'success'
      });
    }
  }
}
</script>

<style scoped>
h1{
  display: inline;
  margin-left: -80%;
  font-size: 26px;
  text-align: left;
  line-height: 70px;

}
.title{
  width: 48%;
  line-height: 70px;
  text-align: left;
  padding-left: 2%;
  font-family: 'Arial Normal', 'Arial';
  font-weight: 400;
}
.exit{
  margin-left: 48%;
  line-height: 70px;
  width: 50%;
  margin-top: -85px;
  text-align: right;
  padding-right: 2%;
}
table,table tr th, table tr td { 
border:1px solid #151515; 
}
table{ 
  width: 100%; 
  min-height: 35px; 
  line-height: 35px; 
  text-align: center; 
  border-collapse: collapse; 
  padding:2px;
}   
.top{
  height: 70px;
  width: 100%;
  margin-top: 0px;
  background-color: rgb(239, 239, 239);
}
.content{
  height: 60px;
}
.isOpen{
  display: none;
}
.time{
  color: #606266;
  font-size: 14px;
  /* background-color: rebeccapurple; */
}
</style>


